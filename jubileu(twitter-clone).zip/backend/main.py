from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import os
from dotenv import load_dotenv
from sqlalchemy import create_engine

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")
engine = create_engine(DATABASE_URL)

app = FastAPI()

# Caminho absoluto para o build do React
frontend_build_path = Path(__file__).resolve().parent.parent / "frontend" / "build"

# Montar os arquivos estáticos do React
app.mount("/", StaticFiles(directory=frontend_build_path, html=True), name="static")
